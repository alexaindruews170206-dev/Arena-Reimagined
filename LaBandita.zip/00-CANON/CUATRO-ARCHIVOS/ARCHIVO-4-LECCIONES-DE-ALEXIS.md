# Archivo 4 — referencia histórica

La fuente de trabajo vigente es [`LECCIONES-ALEXIS.md`](../LECCIONES-ALEXIS.md). Este archivo antes repetía lecciones y ejemplos; se conserva sin cambios en [`_versiones/ARCHIVO-4-LECCIONES-DE-ALEXIS-congelado-2026-10-01.md`](../../_versiones/ARCHIVO-4-LECCIONES-DE-ALEXIS-congelado-2026-10-01.md).

Los volúmenes históricos de Archivo 4 permanecen en `volumenes/`. No uses el snapshot como norma vigente si contradice la petición actual o las Lecciones revisadas.
