# Archivo 1 — referencia histórica

La fuente de trabajo vigente es [`TRATADO.md`](../TRATADO.md). Este archivo antes contenía una compilación extensa de reglas; se conserva sin cambios en [`_versiones/ARCHIVO-1-CODIGO-DE-REGLAS-congelado-2026-10-01.md`](../../_versiones/ARCHIVO-1-CODIGO-DE-REGLAS-congelado-2026-10-01.md).

Los volúmenes históricos de Archivo 1 permanecen en `volumenes/`. No uses el snapshot como norma vigente si contradice la petición actual o el Tratado revisado.
