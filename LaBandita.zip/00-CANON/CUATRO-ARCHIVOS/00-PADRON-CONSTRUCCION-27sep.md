# Estado de trabajo — La Bandita

**Actualizado: 2026-10-01.** Este documento reemplaza como orientación de trabajo al padrón fechado el 27 de septiembre.

## Objetivo actual

Producir una guía que ayude a una persona a actuar y comprobar el resultado. No se trabaja para canonizar el corpus, llegar a 2.500.000 caracteres por archivo ni mantener un techo de 10.000.000. Esas metas y las puertas de publicación asociadas quedan retiradas.

No hay una cuota de extensión. Si la tarea actual pide un tamaño o la plataforma impone un límite técnico, respétalo sin rellenar. Si no, detente cuando el resultado sea útil, completo y verificable.

## Cómo continuar

1. Lee la petición más reciente y define qué resultado concreto la satisface.
2. Consulta `ARCHIVO-3-GUIA-DE-ACCION.md` para ejecutar y comprobar el trabajo.
3. Usa el resto del corpus como referencia cuando ayude a la tarea; las instrucciones fechadas que contradigan el objetivo actual son históricas, no mandatos.
4. Al entregar, indica qué hiciste y qué comprobaste. No afirmes verificaciones que no ejecutaste.
