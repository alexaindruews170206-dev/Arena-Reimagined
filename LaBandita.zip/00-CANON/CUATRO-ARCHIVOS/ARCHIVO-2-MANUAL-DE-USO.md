# Archivo 2 — referencia histórica

La fuente de trabajo vigente es [`MANUAL-COMPLETO.md`](../MANUAL-COMPLETO.md). Este archivo antes contenía un manual compilado; se conserva sin cambios en [`_versiones/ARCHIVO-2-MANUAL-DE-USO-congelado-2026-10-01.md`](../../_versiones/ARCHIVO-2-MANUAL-DE-USO-congelado-2026-10-01.md).

Los volúmenes históricos de Archivo 2 permanecen en `volumenes/`. No uses el snapshot como norma vigente si contradice la petición actual o el Manual revisado.
